//Create a random number generator
  // we import the fuction random from random
  // print the title of the game
  // Then we set up a while loop equal to true so that it will only run if its true
  // Make a varibel to store the random number that will be given to you but the import fucntion 
//Tell User that there are only 5 tries, and begin taking User Input
  //Create a print statement asking User to guess
//Compare all possible outcomes of the game
  //Possible Outcomes: User guess is less than, User guess is greater than, User guess is equal to
  //Set up for loop to determine the number of times the player has already guessed
//If User guesses incorrectly, game will say whether the guess was too small or too high
  //Use if-else statements to compare User Guesses to the random number generator
//Test for both winning and losing the game
  //Input the incorrct number 5 times to see the outcome
  //Input the corrrect number to see the outcome
