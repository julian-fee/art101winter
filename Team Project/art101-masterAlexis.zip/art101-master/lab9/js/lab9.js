var outputEl = document.getElementById('content');
var new1El = document.createElement('p')
new1El.innerHTML = "This is the new section.";
document.body.appendChild(new1El)
var new2El = document.createElement('p')
new2El.innerHTML = "This is the second section.";
document.body.appendChild(new2El)
