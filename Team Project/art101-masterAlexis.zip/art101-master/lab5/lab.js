/**
* Lab 5: Data Types and Varibles
  Author: Alexis
* Created: 1/26/2021
**/
// This is the information of the car that we chose
var make = "BMW"
var model = "325i"
var color = "grey"
var year = 2006
// here is where we subtract to find out how old the car is
var age = 2021 - year

// here is where we make the lines of code to be display on our webpage
document.writeln("Make: " + make + "<br>");
document.writeln("Model: " + model + "<br>");
document.writeln("Color: " + color + "<br>");
document.writeln("Year: " + year + "<br>");
document.writeln("Age: " + age + "<br>");
